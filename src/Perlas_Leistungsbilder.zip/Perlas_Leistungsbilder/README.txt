PERLAS – Bilder für Leistungsseiten

Die neun JPG-Dateien im Hauptordner sind echte Projektfotos und können in passenden Leistungsseiten-Galerien verwendet werden. Schwerpunkt: Gartenpflege, Wege, Eingänge, Innenhöfe und gepflegte Wohnanlagen. Ein Motiv darf auf mehreren passenden Leistungsseiten erscheinen.

Gartenpflege_Arbeitsgeraet_am_Heckenweg.jpg – Gartenarbeit am Heckenweg; als ergänzendes Arbeitsfoto einsetzen.
Gartenpflege_Gepflegter_Gartenweg_01.jpg – gepflegter Gartenweg zwischen Hecke und Grünbewuchs.
Gartenpflege_Gepflegter_Gartenweg_02.jpg – zweite Ansicht desselben gepflegten Weges.
Aussenanlagen_Gepflasterter_Weg_am_Gebaeude.jpg – gepflasterter Weg entlang eines Gebäudes.
Objektbetreuung_Wohnanlage_Aussenansicht.jpg – Wohnanlage mit gepflegtem Außenbereich.
Objektbetreuung_Gepflegter_Eingangsbereich.jpg – Eingangsbereich und gepflegte Außenfläche.
Objektbetreuung_Gepflegter_Hof_Wohngebaeude.jpg – aufgeräumter Hof vor einem Wohngebäude.
Objektbetreuung_Gepflegter_Hof_Backsteingebaeude.jpg – sauberer Hofbereich vor einem Backsteingebäude.
Objektbetreuung_Innenhof_Arbeitseinsatz.jpg – gepflasterter Innenhof während eines Arbeitseinsatzes.

Der Unterordner REFERENZ_nicht_als_Seitenbild enthält einen Screenshot einer bestehenden Vorher-Nachher-Darstellung. Er dient nur als Design-/Inhaltsreferenz und darf nicht als echtes Projektfoto eingebaut werden.
