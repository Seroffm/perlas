PERLAS – Mitarbeiterbild ersetzen

Datei:
mitarbeiter_rechts_unten_ersetzen.png

Verwendung:
Dieses Bild soll im Mitarbeiterbereich auf der Über-uns-Seite für die Karte rechts unten
verwendet werden und das dort aktuell vorhandene Mitarbeiterbild ersetzen.

Wichtig:
- Bild nicht verzerren.
- Sinnvollen Fokus auf Gesicht und Oberkörper setzen.
- Auf Desktop und Mobile prüfen.
- Bestehende Kartengröße und Reihenfolge beibehalten.
